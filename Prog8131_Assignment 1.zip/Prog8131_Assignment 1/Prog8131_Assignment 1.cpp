/*******************************************************************************************
* File Name          : PROG8130Assign1.cpp
* Description        : Prog8130 - Assignment 1: Linked Lists (revised June 9, 2022)
*					   This program uses linked lists to store and print a list of words that are
*					   organized by an "index number" assosciated with each word. Each word can
*					   consist of maximum MAX_STRING_LEN-1 characters.
*
* Author              :Mohamed Yusuf
* Date                :09/24/2024
* Reference           :Youtube Videos and Explanation on code with the help of Co-pilot
********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUMBER_OF_DATA_ITEMS   10					// the number of data items to be used in list
#define MAX_STRING_LEN		   30

// structure/typedef used for holding data
typedef struct {
	char name[MAX_STRING_LEN];					// "string" data to be stored in the linked list.
	int index;									// position in linked list to put the data into
	// the "index" is used to determine where to put the data.
	// For example an indes of 0 or 1 would always put the data
	// at the start of the current linked list at that moment of time.
	// An "index" number larger than the number of linked list nodes
	// would have the effect of putting the new node on the end of the list.
	// Any other "index" value would place it at the location
} inputData;

// definition of linked list data nodes
typedef struct LinkedListNode {
	struct LinkedListNode* ptrNextNode;				// pointer to next node in list (NULL if the end)
	char					NameData[MAX_STRING_LEN];	// the name to be stored 
} LinkedListNodeDef;									// DO NOT STORE THE "index" from inputData because it
// has no meaning after the insertion into linked list


// function prototypes
LinkedListNodeDef* AddToLinkedList(LinkedListNodeDef* ptrHead, char* NameData, int DataIndex);
void				PrintLinkedList(LinkedListNodeDef* ptrHead);


// make the data positions the last 4 digits of student number
// for example if my student number ended in 94330 the data will be as supplied

// data used for test
// paste the data here that was created by Prog8130Assign1DataCreator.exe
// Used the following data in assignment #1
inputData iData[10] = {
		{ "fish", 7 },
		{ "carrot", 8 },
		{ "car", 5 },
		{ "allan", 1 },
		{ "milk", 3 },
		{ "butter", 3 },
		{ "kiwi", 1 },
		{ "airplane", 3 },
		{ "orange", 3 },
		{ "pickels", 7 }
};
//end of data for assignment

// Correct order after inserting into list is:
// 1. kiwi
// 2. allan
// 3. orange
// 4. airplane
// 5. fish
// 6. butter
// 7. pickels
// 8. milk
// 9. carrot
// 10. car

int main(void) {
	int i;

	// define linked list start/head
	struct LinkedListNode* ptrHead = NULL;

	// Print out the input data
	printf("Data before inserting into the Linked List is:\n");
	for (i = 0; i < NUMBER_OF_DATA_ITEMS; i++)
		printf("%s, %d\n", iData[i].name, iData[i].index);

	// insert the data into Linked List
	for (i = 0; i < NUMBER_OF_DATA_ITEMS; i++)
		ptrHead = AddToLinkedList(ptrHead, iData[i].name, iData[i].index);

	// now print out the list in order it is stored starting at head
	PrintLinkedList(ptrHead);

	return 0;
}

// FUNCTION      : AddToLinkedList()
// 
// DESCRIPTION   : This function takes an input of Data of 30 Char word and an index and 
//				   places them in a linked list organized by priority of index number. 
// 
// PARAMETERS    : LinkedListNodeDef *ptrHead	- current head of the linked list
//				   char *NameData				- Array of Characters with data (a "string")
//		           int DataIndex				- Index of data (postion to put the data in the list)
// RETURNS       : possibly updated pointer to the head of the list 
//				   (updated ptrHead if insertion was to start of list)

LinkedListNodeDef* AddToLinkedList(LinkedListNodeDef* ptrHead, char* NameData, int DataIndex) {
	// put your code in here to add the item(s) to the linked list based off the "DataIndex" given
	// this code should make the decision to put the data at the start/end or somewhere between the start and end

	LinkedListNodeDef* newNode = (LinkedListNodeDef*)malloc(sizeof(LinkedListNodeDef));  // Allocate memory for a new node
	strcpy_s(newNode->NameData, NameData);
	newNode->ptrNextNode = NULL;  // Initially, the new node points to NULL

	if
		(DataIndex <= 1 || !ptrHead)            // Data inserted at strat
	{
		newNode->ptrNextNode = ptrHead;        // Point the new node to the current head of the list
		return newNode;                       // Return the new node as the new head of the list
	}
	                                          // Otherwise, we need to find the appropriate place in the list to insert the new node
	LinkedListNodeDef* current = ptrHead;     // Start from the head of the list
	LinkedListNodeDef* previous = NULL;      // Keep track of the previous node
	int count = 1;                            // Initialize a counter to track position in the list
	                                            
	                                          // Traverse the list until we find the correct index or reach the end of the list
	while
		(current && count < DataIndex)
	{
		previous = current;                   // Move the previous pointer to the current node
		current = current->ptrNextNode;       // Move the current pointer to the next node
		count++;                              // Increment the position counter
	}

	                                      // If we have a valid previous node, insert the new node between previous and current
	if
		(previous)
	{
		previous->ptrNextNode = newNode;    // Point the previous node's next pointer to the new node
		newNode->ptrNextNode = current;      // Point the new node's next pointer to the current node
	}
	else
		                // If there's no valid previous node (unlikely in this implementation), the new node becomes the head
	{
		newNode->ptrNextNode = ptrHead;
		ptrHead = newNode;
	}

	return ptrHead;
}

// FUNCTION      : PrintLinkedList()
// 
// DESCRIPTION   : This function takes an input of the head of the linked list, then loops through
//				   and prints each word in the linked list until the ptrNextNode is NULL (end of list).
// 
// PARAMETERS    : 
//				   LinkedListNodeDef *ptrHead - A pointer to the start of the linked list
// RETURNS       : void (nothing)

void PrintLinkedList(LinkedListNodeDef* ptrHead) {
	LinkedListNodeDef* currentNode;

	printf("\nData after inserting into the Linked List is:\n");

	// put code in here to print the linked list out
	// go through the linked list from the start (ptrHead) and use ptrNextNode to find the next node to be
	// printed until you reach a ptrNextNode == NULL which signifies the end of the list

	                                            // Start from the head and go through the list, printing each node's data
	LinkedListNodeDef* current = ptrHead;
	while (current != NULL)
	{
		printf("%s\r\n", current->NameData);    // Print the NameData of the current node
		current = current->ptrNextNode;         // Move to the next node in the list
	}
	return;
}
